




class CPF_data(numpy.array, detector_type, calibration_type):

    if detector_type is dioptas:
        CPF_data=CPF_Data(dioptas)
    data= [x, y, I]
    def self.convert():
        [twotheta,azimuth,I] = work on array here

    def self.x:
        return data[x]

    def self.y:
        return data[y]

    def self.twoth:
        return self.convert()[:]



class detector_type(choice)
    def self.initialplot




inputdata=CPF_data(data)

new_inputdata = inputdata.convert()
inputdata.detector.wavelength = wavelength for detector

new_inputdata.calibrate


make class wider and include fitting parameters as part of class.